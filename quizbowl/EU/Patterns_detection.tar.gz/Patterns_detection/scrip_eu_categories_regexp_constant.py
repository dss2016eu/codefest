
import re

#Place, Person, Writer, Work, Animal, Year

# Person: "ibili zen" "jaio zen" "hil zen" "idatzi zuen" "sortzaile*" "ikasle izan zen" "idazle/kritikari/eragile * izan zen" "idazlea" "poeta" "ren aita/ama" "idatzi zuen"

# INPUT: [...w1, w2, w3,...]

#person_re = re.compile("(ibili|hil|jaio|ikasle|irakasle|idazle|poeta|autore|idazlari|kritikari|eragile|ren (seme|aita|ama)) (izan) zen | (idatzi|eraiki|antolatu) zuen | (gizon|emakume|zientzialari) (hau|honek)" )

person_re = re.compile("(ibili|hil|jaio|ikasle|irakasle|idazle|poeta|kritikari|eragile)(a)? (izan )?zen| (idatzi|eraiki|antolatu) zuen| (gizon|emakume|zientzialari) (hau|honek)")


writer_re = re.compile("idazle|poeta|autore|idazlari")

place_re = re.compile("(hiriburu|hizkuntza ofizial|biztanle|estatu)(a)")

animal_re = re.compile("ren ordena | burua | arrautza")

work_re = re.compile("(tako|ren) (margolan|liburu|eleberri|poema|ipuin)")

year_re = re.compile("urte(an| honetan| hartan)")

def categorize_eu(tokenizewords):
	wordstring = ' '.join(tokenizewords)
	if re.findall(person_re, wordstring):
		if re.findall(writer_re, wordstring):
			return('Writer')
		else:
			return('Person')
	elif re.findall(place_re, wordstring):
		return('Place')
	elif re.findall(animal_re, wordstring):
		return('Animal')
	elif re.findall(work_re, wordstring):
		return('Work')
	elif re.findall(year_re, wordstring):
		return('Year')
	else:
		return('Other')

sent1 = ['ohikatu', 'zuen', 'hainbat', 'mirari', 'egin', 'zituen', 'bere', 'bizitzan', 'zehar', 'Galilea', 'eta', 'Judea', 'lurraldeetan', 'zehar', 'antolatu', 'zuen', 'bere', 'mezua', 'zabaltzen', 'eta', 'mirariak', 'egiten']

sent2 = ['joan zen']

sent3 = ['urtean','izan','zen']

print(categorize_eu(sent3))



