#!/usr/bin/python3
# -*- coding: utf-8 -*-

#CSV-ak kudeatzeko:
import csv
import re

def look_for(word,word_list):
	if word in word_list:
                return(True)
	else:
                return(False)


def pattern_match(question):
  #      print(question)
        question_list = question.split()
   #     print(len(question_list))
        i=0
        while (i < len(question_list)):
                with open(pattern_file,newline='') as csv_pattern:
                        pattern_object = csv.DictReader(csv_pattern)
    #                    print(pattern_object.fieldnames)
                        for line_p in pattern_object:
                               pattern = line_p["Pattern"].strip()
                               kategoria = line_p["Category"].strip()
                               pattern = pattern.split()
     #                          print(pattern)
      #                         print(question_list[i])
       #                        print(pattern[0])
                               reg_expression=re.compile(pattern[0]) ##
                               match=re.findall(reg_expression,question_list[i]) ##
                        ##       match=(question_list[i]==pattern[0])
                               j=0
                               k=i
                               while match and (j < len(pattern)) and (k < len(question_list)):
                                   reg_expression=re.compile(pattern[j]) ##
                                   if not re.findall(reg_expression,question_list[k]):
                           ##        if (question_list[k]!=pattern[j]):
                             #             print(pattern[j])
                                          match=False
                                   j=j+1
                                   k=k+1
                               if match:
                                  print("Question: "+question)
                                  print("Pattern: ")
                                  print(pattern)
                                  print("Category: "+kategoria)
                                  print("")
                               
                i=i+1


            
sar_fitx = "input_questions.csv"
pattern_file = "input_patterns.csv"

#Sarrera fitxategia ireki
with open(sar_fitx,newline='') as csv_input:
    #Sarrera fitxategia hiztegi batean kargatu
	reader_object = csv.DictReader(csv_input)
#	print(reader_object.fieldnames)
	for line in reader_object:
		question = line["Question"].strip()
		pattern_match(question)

            
